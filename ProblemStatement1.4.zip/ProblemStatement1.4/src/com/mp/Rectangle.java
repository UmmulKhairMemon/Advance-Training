package com.mp;

import java.util.Scanner;

public class Rectangle {
	float length; 
    float breadth; 
    double area;
    double perimeter;
    
	public Rectangle() {
		super();
		length=1;
		breadth=1;
	    }
        
		public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public float getBreadth() {
		return breadth;
	}

	public void setBreadth(float breadth) {
		this.breadth = breadth;
	}

	void input() {
		Scanner scan = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = scan.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = scan.nextInt();
        }
	     
	    void calculate_area()
	    {
	    	area=length*breadth;
	    }
	    
	    void calculate_perimeter()
	    {
	    	perimeter=2*(length+breadth);
	    }
	    
	    void display()
	    {
	    	if(length>0.0 && length<20.0)
	    	{
	    	System.out.println("Area of rectangle="+area);
	    	System.out.println("Perimeter of rectangle="+perimeter);
	    }
	    	else
	    	{
	    		System.out.println("Length and Breadth value should be greater than 0.0 and less than 20.0 ");
	    	}
	    }
	    public static void main(String[] args) {
			
			Rectangle obj1 = new Rectangle();
	        obj1.input();
	        obj1.calculate_area();
	        obj1.calculate_perimeter();
	        obj1.display();
	        System.out.println("----------------------------");

	        Rectangle obj2 = new Rectangle();
	        obj2.input();
	        obj2.calculate_area();
	        obj2.calculate_perimeter();
	        obj2.display();
	        System.out.println("----------------------------");
	        
	        Rectangle obj3 = new Rectangle();
	        obj3.input();
	        obj3.calculate_area();
	        obj3.calculate_perimeter();
	        obj3.display();
	        System.out.println("----------------------------");
	        
	        Rectangle obj4 = new Rectangle ();
	        obj4.input();
	        obj4.calculate_area();
	        obj4.calculate_perimeter();
	        obj4.display();
	        System.out.println("----------------------------");
	        
	        Rectangle obj5 = new Rectangle();
	        obj5.input();
	        obj5.calculate_area();
	        obj5.calculate_perimeter();
	        obj5.display();
	        System.out.println("----------------------------");

		}
	    
	    

    
    


}
