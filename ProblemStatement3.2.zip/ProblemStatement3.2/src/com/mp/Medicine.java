package com.mp;
public class Medicine {
	
	public void displayLabel() {
		System.out.println("Company : Netmeds");
		System.out.println("Address : Chennai");
		}
	}

class Tablet extends Medicine {
	
	public void displayLabel() {
		System.out.println("store in a cool dry place");
		}
	}

class Syrup extends Medicine {
	
	public void displayLabel() {
		System.out.println("Shake before use");
		}
	}

class Ointment extends Medicine {
	
	public void displayLabel() {
		System.out.println("For external use only");
		}
	}
