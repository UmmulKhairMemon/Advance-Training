package com.mp;

import java.util.Scanner;

public class Rectangle {
	int length; 
    int breadth; 
    int area;
    
	public Rectangle() {
		super();
		length=0;
		breadth=0;
	    }
	
	    void input() {
		Scanner scan = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = scan.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = scan.nextInt();
        }
	     
	    void calculate()
	    {
	    	area=length*breadth;
	    }
	    
	    void display()
	    {
	    	System.out.println("Area of rectangle="+area);
	    }

    
    


}
