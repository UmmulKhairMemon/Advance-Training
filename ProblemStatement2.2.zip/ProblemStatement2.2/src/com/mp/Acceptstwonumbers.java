package com.mp;

import java.util.Scanner;

public class Acceptstwonumbers {
	
	public static void main(String[] args) {
		
		int i = 1, n = 13, 
		firstnum = 0, secondnum = 1;
		
		  Scanner sc = new Scanner(System.in);
		 
	      System.out.println("Enter a First number:");
	      firstnum = sc.nextInt();
	      
	      System.out.println("Enter a First number:");
	      secondnum = sc.nextInt();
		
	    System.out.println("Fibonacci Series till " + n + " terms:");

	    while (i <= n) {
	      System.out.print(firstnum + ", ");

	      int nextTerm = firstnum + secondnum;
	      firstnum = secondnum;
	      secondnum = nextTerm;

	      i++;
	    }

	}

}
