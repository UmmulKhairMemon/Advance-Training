package com.mp;

import java.util.Scanner;

public class ProblemStatement1 {

	public static void main(String[] args) {
		
        int num;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number:");
		num = sc.nextInt();
		
		for(int i=0;i<=num;i++)
		{
			if(i%2==0)
			{
				System.out.println("Even number="+i);
			}
		}
  }
}
